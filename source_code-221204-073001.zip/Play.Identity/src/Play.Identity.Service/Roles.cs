namespace Play.Identity.Service
{
    public static class Roles
    {
        public const string Admin = "Admin";
        public const string Player = "Player";
    }
}